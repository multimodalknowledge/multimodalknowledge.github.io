#!/usr/bin/env sh

/home/nfd/mycaffe/multilabel/caffe-master/build/tools/caffe train \
    --solver=/home/nfd/mycaffe/multilabel/testdata/solver.prototxt
