#!/usr/bin/env sh

/home/nfd/mycaffe/multilabel/caffe-master/build/tools/caffe train \
    --solver=/home/nfd/mycaffe/multilabel/testdata/solver.prototxt \
    --snapshot=/home/nfd/mycaffe/multilabel/testdata/model_full/caffenet_train_iter_680000.solverstate
